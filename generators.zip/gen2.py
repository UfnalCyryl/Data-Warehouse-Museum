import pandas as pd
import random
from datetime import datetime, timedelta

# Helper function to generate unique PESELs
def generate_pesel(i):
    return f"{10000000000 + i}"  # Ensures unique PESELs based on counter

# Load previous snapshot T1 data
try:
    df_donations_t1 = pd.read_csv("Donations.csv")
    df_artists_t1 = pd.read_csv("Artist.csv")
    df_patrons_t1 = pd.read_csv("Patron.csv")
    df_artworks_t1 = pd.read_csv("Artwork.csv")
    last_invoice_num = max([int(i[3:]) for i in df_donations_t1["INVOICE_NUMBER"]])
    last_artist_id = df_artists_t1.shape[0]
    last_patron_id = df_patrons_t1.shape[0]
    last_artwork_id = df_artworks_t1.shape[0]
except FileNotFoundError:
    df_donations_t1 = pd.DataFrame()
    df_artists_t1 = pd.DataFrame()
    df_patrons_t1 = pd.DataFrame()
    df_artworks_t1 = pd.DataFrame()
    last_invoice_num = 0
    last_artist_id = 0
    last_patron_id = 0
    last_artwork_id = 0

# Modify 1 existing artist for dimension change
if not df_artists_t1.empty:
    df_artists_t1.loc[0, "Nationality"] = f"UpdatedNationality_{datetime.now().strftime('%Y%m%d')}"

# Add several new artists
new_artists = []
for i in range(1, 5):
    birth_year = random.randint(1850, 1980)
    death_year = random.randint(birth_year + 20, min(birth_year + 80, 2023)) if random.random() > 0.5 else 0
    nationalities = ["Spanish", "French", "Italian", "German", "American", "British", "Japanese"]
    first_names = ["John", "Maria", "Hans", "Jean", "Marco", "Emma", "Yuki", "Zhang"]
    last_names = ["Smith", "Gonzalez", "Mueller", "Dubois", "Rossi", "Johnson", "Tanaka", "Wang"]
    
    new_artists.append({
        "PESEL": generate_pesel(last_artist_id + i),
        "Birth_year": birth_year,
        "Death_year": death_year,
        "Nationality": random.choice(nationalities),
        "Name": random.choice(first_names),
        "Surname": random.choice(last_names)
    })

df_artists_t2 = pd.concat([df_artists_t1, pd.DataFrame(new_artists)], ignore_index=True)

# Modify 1 existing patron
if not df_patrons_t1.empty:
    df_patrons_t1.loc[0, "Address"] = f"Updated Address {datetime.now().strftime('%Y%m%d')}"

# Add several new patrons
new_patrons = []
for i in range(1, 5):
    membership_levels = ["Bronze", "Silver", "Gold", "Platinum"]
    statuses = ["Active", "Inactive"]
    types = ["Individual", "Corporate"]
    first_names = ["John", "Maria", "Hans", "Jean", "Marco", "Emma", "Yuki", "Zhang"]
    last_names = ["Smith", "Gonzalez", "Mueller", "Dubois", "Rossi", "Johnson", "Tanaka", "Wang"]
    addresses = ["Main St", "Park Ave", "Business Blvd", "First St", "Second Ave"]
    
    join_date = datetime.now() - timedelta(days=random.randint(0, 3650))
    
    new_patrons.append({
        "PESEL": generate_pesel(100000 + last_patron_id + i),
        "Type": random.choice(types),
        "Phone_number": f"{random.randint(500000000, 899999999)}",
        "Address": f"{random.randint(1, 999)} {random.choice(addresses)} City",
        "Membership_status": random.choice(statuses),
        "Membership_level": random.choice(membership_levels),
        "Date_joined": random.randint(2020, 2025),
        "Name": random.choice(first_names),
        "Surname": random.choice(last_names)
    })

df_patrons_t2 = pd.concat([df_patrons_t1, pd.DataFrame(new_patrons)], ignore_index=True)

# Get all artist PESELs for artwork creation
all_artist_pesels = df_artists_t2["PESEL"].tolist()

# Add several new artworks
new_artworks = []
for i in range(1, 10):
    types = ["Painting", "Sculpture", "Photography", "Mixed Media", "Drawing", "Installation"]
    mediums = ["Oil", "Watercolor", "Marble", "Bronze", "Acrylic", "Digital", "Wood", "Glass"]
    titles = ["Landscape", "Portrait", "Abstract", "Still Life", "Nature", "Urban Scene", "Dream", "Horizon"]
    
    year_created = random.randint(1900, 2020)
    
    new_artworks.append({
        "ARTWORK_AUTHENTICITY_CERT_NUM": f"CERT_{last_artwork_id + i:05d}",
        "Title": f"{random.choice(titles)} #{last_artwork_id + i}",
        "Year_created": year_created,
        "Type": random.choice(types),
        "Medium": random.choice(mediums),
        "Dimensions": f"{random.randint(30, 200)}x{random.randint(30, 200)}",
        "Permanent": random.choice([0, 1]),
        "Artist_PESEL": random.choice(all_artist_pesels)
    })

df_artworks_t2 = pd.concat([df_artworks_t1, pd.DataFrame(new_artworks)], ignore_index=True)

# Get all patron PESELs and artwork IDs for donation creation
all_patron_pesels = df_patrons_t2["PESEL"].tolist()
all_artwork_ids = df_artworks_t2["ARTWORK_AUTHENTICITY_CERT_NUM"].tolist()

# Add several new donation records
new_donations = []
for i in range(1, 16):
    purposes = ["Restoration", "Acquisition", "Exhibition", "Education", "General Support"]
    donation_date = datetime.now() - timedelta(days=random.randint(0, 365))
    
    new_donations.append({
        "INVOICE_NUMBER": f"INV{last_invoice_num + i:04d}",
        "Amount": round(random.uniform(100.0, 10000.0), 2),
        "Date_of_donation": donation_date.strftime("%Y-%m-%d"),
        "Purpose": random.choice(purposes),
        "Artwork_ID": random.choice(all_artwork_ids),
        "Patron_PESEL": random.choice(all_patron_pesels)
    })

df_donations_t2 = pd.concat([df_donations_t1, pd.DataFrame(new_donations)], ignore_index=True)

borrowed_or_lent = [
    {
        "Borrowing_ID": i,
        "Artwork_ID": random.randint(1, len(df_artworks_t2)),
        "Institution": f"Institution{i}",
        "Start_date": (datetime(2000, 1, 1) + timedelta(days=i * 10)).date(),
        "End_date": (datetime(2000, 1, 1) + timedelta(days=(i * 10 + 30))).date(),
        "Status": random.choice(["Ongoing", "Completed"]),
        "Borrowed": random.choice([0, 1]),
        "Lent": random.choice([0, 1]),
        "Owned": random.choice([0, 1])
    }
    for i in range(1, 11)
]
df_borrowed_or_lent = pd.DataFrame(borrowed_or_lent)

# Export to CSV
snapshot_label = "T2"
df_artists_t2.to_csv(f"Artist_{snapshot_label}.csv", index=False)
df_patrons_t2.to_csv(f"Patron_{snapshot_label}.csv", index=False)
df_artworks_t2.to_csv(f"Artwork_{snapshot_label}.csv", index=False)
df_donations_t2.to_csv(f"Donations_{snapshot_label}.csv", index=False)
df_borrowed_or_lent.to_csv(f"Borrowed_orLent{snapshot_label}.csv", index=False)

print("\u2705 T2 snapshot CSV files generated and saved with updates and multiple new rows.")
