import pandas as pd
import random
from datetime import datetime, timedelta

# Helper function to generate PESELs (11-digit numbers only)
def generate_pesel(i):
    return f"{random.randint(10000000000, 99999999999)}"

# Generate Artist data
artists = [
    {
        "PESEL": generate_pesel(i),
        "Birth_year": (birth_year := random.randint(1500, 2000)),
        "Death_year": random.randint(birth_year + 20, min(birth_year + 80, 2023)) if random.random() > 0.5 else 0,
        "Nationality": random.choice(["Polish", "French", "German", "American", "Italian", "Spanish", "Russian", "Japanese", "Chinese", "Brazilian", "Indian", "British", "Canadian", "Australian", "Mexican"]),
        "Name": random.choice(["Leonardo", "Pablo", "Vincent", "Frida", "Salvador", "Claude", "Georgia", "Michelangelo", "Rembrandt", "Andy"]),
        "Surname": random.choice(["da Vinci", "Picasso", "van Gogh", "Kahlo", "Dali", "Monet", "OKeeffe", "Buonarroti", "van Rijn", "Warhol"])
    }
    for i in range(1, 100)
]
df_artists = pd.DataFrame(artists)

# Generate Patron data
# Lists of common first names and surnames
first_names = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", "William", "Elizabeth", 
               "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Charles", "Karen",
               "Christopher", "Nancy", "Daniel", "Lisa", "Matthew", "Margaret", "Anthony", "Betty", "Mark", "Sandra",
               "Donald", "Ashley", "Steven", "Dorothy", "Paul", "Kimberly", "Andrew", "Emily", "Joshua", "Donna"]

surnames = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor",
            "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Garcia", "Martinez", "Robinson",
            "Clark", "Rodriguez", "Lewis", "Lee", "Walker", "Hall", "Allen", "Young", "Hernandez", "King",
            "Wright", "Lopez", "Hill", "Scott", "Green", "Adams", "Baker", "Gonzalez", "Nelson", "Carter"]

# Generate Patron data
patrons = [
    {
        "PESEL": generate_pesel(i + 100),
        "Type": random.choice(["Individual", "Organization"]),
        "Phone_number": f"{random.randint(500000000, 899999999)}",
        "Address": f"Street {i} City",
        "Membership_status": random.choice(["Active", "Expired", "None"]),
        "Membership_level": random.choice(["Platinum", "Gold", "Silver", "Bronze"]),
        "Date_joined": random.randint(1500, 2000),
        "Name": random.choice(first_names),
        "Surname": random.choice(surnames)
    }
    for i in range(1, 60000)
]
df_patrons = pd.DataFrame(patrons)

# Generate Artwork data
artworks = [
    {
        "ARTWORK_AUTHENTICITY_CERT_NUM": f"CERT{i:05d}",

        "Title": f"Artwork Title {i}",
        "Year_created": random.randint(1900, 2020),
        "Type": random.choice(["Painting", "Sculpture"]),
        "Medium": random.choice(["Oil", "Watercolor", "Marble", "Bronze"]),
        "Dimensions": f"{random.randint(30, 200)}x{random.randint(30, 200)}",
        "Permanent": random.choice([0, 1]),
        "Artist_PESEL": random.choice(df_artists["PESEL"])
    }
    for i in range(1, 110000)
]
df_artworks = pd.DataFrame(artworks)

# Generate Donations data
# Generate random dates between 2000 and current year
def random_date():
    year = random.randint(2000, datetime.now().year)
    month = random.randint(1, 12)
    day = random.randint(1, 28)  # Using 28 to avoid month/day validity issues
    return f"{year}-{month:02d}-{day:02d}"  # SQL-compatible YYYY-MM-DD format

donations = [
    {
        "INVOICE_NUMBER": f"INV{i:04d}",
        "Amount": round(random.uniform(100.0, 5000.0), 2),
        "Date_of_donation": random_date(),
        "Purpose": random.choice(["Restoration", "Acquisition", "Conservation", "Exhibition", "Education", "Research", "Facility Improvement", "Special Events"]),
        "Artwork_ID": random.choice(df_artworks["ARTWORK_AUTHENTICITY_CERT_NUM"]),
        "Patron_PESEL": random.choice(df_patrons["PESEL"])
    }
    for i in range(1, 10001)
]
df_donations = pd.DataFrame(donations)

borrowed_or_lent = [
    {
        "Borrowing_ID": i,
        "Artwork_ID": random.randint(1, len(df_artworks)),
        "Institution": f"Institution{i}",
        "Start_date": (datetime(2000, 1, 1) + timedelta(days=i * 10)).date(),
        "End_date": (datetime(2000, 1, 1) + timedelta(days=(i * 10 + 30))).date(),
        "Status": random.choice(["Ongoing", "Completed"]),
        "Borrowed": random.choice([0, 1]),
        "Lent": random.choice([0, 1]),
        "Owned": random.choice([0, 1])
    }
    for i in range(1, 11)
]
df_borrowed_or_lent = pd.DataFrame(borrowed_or_lent)



# Export to CSV
df_artists.to_csv("Artist.csv", index=False)
df_patrons.to_csv("Patron.csv", index=False)
df_artworks.to_csv("Artwork.csv", index=False)
df_donations.to_csv("Donations.csv", index=False)
df_borrowed_or_lent.to_csv(f"Borrowed_orLent.csv", index=False)

print("\u2705 CSV files generated and saved.")